package com.EvenNumber;
import java.util.Scanner;
public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       Scanner s = new Scanner(System.in);
	       System.out.print("Enter value n : ");
	       int n = s.nextInt();
	       for(int i=0; i<n; i++)
	       {
	    	   if(i%2==0)
	       System.out.print(i+" ");
	 }    
	}

}
