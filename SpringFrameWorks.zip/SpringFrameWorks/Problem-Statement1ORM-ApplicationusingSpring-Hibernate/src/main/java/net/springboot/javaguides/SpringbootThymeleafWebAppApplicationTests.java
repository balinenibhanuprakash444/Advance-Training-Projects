package net.springboot.javaguides;
//import org.junit.Test;
//import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringbootThymeleafWebAppApplicationTests {
	//@Test
	void contextLoads() {
	}

}
