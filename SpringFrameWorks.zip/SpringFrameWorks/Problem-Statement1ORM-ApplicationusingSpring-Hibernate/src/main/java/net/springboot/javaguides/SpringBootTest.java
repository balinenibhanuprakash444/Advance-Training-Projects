package net.springboot.javaguides;

public @interface SpringBootTest {

}
